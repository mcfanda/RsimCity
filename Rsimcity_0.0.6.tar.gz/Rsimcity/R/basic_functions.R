#' Generate a correlated sample
#'
#' @description
#' Generate a data frame containing `N` observations from a multivariate normal
#' distribution with a specified correlation matrix, means, and standard
#' deviations.
#'
#' @param N Integer. Number of observations to generate.
#' @param R Numeric matrix. A positive definite correlation matrix. The number of
#'   rows and columns defines the number of generated variables.
#' @param mu Numeric vector. Means of the generated variables. If a single value
#'   is supplied, it is recycled across variables. Default is `0`.
#' @param sd Numeric vector. Standard deviations of the generated variables. If a
#'   single value is supplied, it is recycled across variables. Default is `1`.
#' @param seed Optional integer. Random seed used for reproducible sampling.
#'   Default is `NULL`.
#'
#' @return A data frame with `N` rows and `K` columns, where `K = nrow(R)`.
#'   Variables are named `x1`, `x2`, ..., `xK`.
#'
#' @details
#' The function first generates independent standard normal variables and then
#' applies the Cholesky decomposition of `R` to induce the requested correlation
#' structure. The variables are then rescaled using `sd` and shifted using `mu`.
#'
#' `R` must be a square, symmetric, positive definite matrix.
#'
#' @examples
#' R <- matrix(
#'   c(1.0, 0.5,
#'     0.5, 1.0),
#'   nrow = 2,
#'   byrow = TRUE
#' )
#'
#' dat <- correlated_sample(N = 100, R = R, mu = c(0, 2), sd = c(1, 3))
#' head(dat)
#' cor(dat)
#'
#' @importFrom stats rnorm
#' @export
correlated_sample <- function(N, R, mu = 0, sd = 1, seed = NULL) {

  if (!is.null(seed)) set.seed(seed)
  K <- nrow(R)
  Sigma <- R

  if (!is.matrix(Sigma)) stop("R must be either a scalar or a correlation matrix")
  if (nrow(Sigma) != ncol(Sigma)) stop("R matrix must be K x K")
  if (!isTRUE(all.equal(Sigma, t(Sigma)))) stop("R must be symmetric")
  if (any(eigen(Sigma, symmetric = TRUE)$values <= 0)) stop("R must be positive definite")

  mu <- rep(mu, length.out = K)
  sd <- rep(sd, length.out = K)

  Z <- matrix(stats::rnorm(N * K), nrow = N, ncol = K)
  X <- Z %*% chol(Sigma)

  X <- sweep(X, 2, sd, FUN = "*")
  X <- sweep(X, 2, mu, FUN = "+")

  colnames(X) <- paste0("x", seq_len(K))
  as.data.frame(X)
}

bind_list_cols <- function(df, x) {

  if (!is.data.frame(df))
    stop("df must be a data.frame")

  keep <- vapply(x, function(z) {
    (is.numeric(z) || is.character(z) || is.logical(z)) && length(z) == 1
  }, logical(1))

  x <- x[keep]

  if (length(x) == 0)
    return(df)

  xdf <- as.data.frame(x, stringsAsFactors = FALSE)

  xdf <- xdf[rep(1, nrow(df)), , drop = FALSE]
  rownames(xdf) <- NULL
  rownames(df) <- NULL
  cbind(xdf, df)
}
#' Count elements
#'
#' @description
#' Count the frequency of elements of a vector in another vector
#' @param V Character vector of values to count
#' @param X Vector in which to count occurrences of `V`
#' @export
count_names <- function(V, X) {
  out <- tabulate(match(X, V), nbins = length(V))
  names(out) <- V
  out
}


### makes column means for numeric and use the first entry for character columns
numColMean <- function(x) {
  means <- lapply(names(x), function(name) {
    if (is.numeric(x[[name]])) {
      return(mean(x[[name]], na.rm = TRUE))
    }
    x[[name]][1]
  })

  names(means) <- names(x)
  as.data.frame(means, stringsAsFactors = FALSE, check.names = FALSE)
}

print_params <-function(x) {
  lapply(x, function(z) {
    if ((is.numeric(z) || is.character(z) || is.logical(z)) && length(z) == 1)
       return(x)
  else
       return(class(x)[1])
  })
}



######### this is for parellel to work fine

.collect_user_objects <- function(env = .GlobalEnv, objects = NULL) {

  nms <- ls(envir = env, all.names = TRUE)

  if (length(nms) == 0) {
    return(list())
  }

  if (!is.null(objects)) {
    missing <- setdiff(objects, nms)

    if (length(missing) > 0) {
      stop(
        "These requested objects were not found in `env`: ",
        paste(missing, collapse = ", "),
        call. = FALSE
      )
    }
  }

  objs <- mget(nms, envir = env, inherits = FALSE)

  is_fun <- vapply(objs, is.function, logical(1))

  keep_extra <- names(objs) %in% objects

  objs[is_fun | keep_extra]
}

### this is just aesthetics

.running_in_rscript <- function() {
  exe <- basename(commandArgs()[1])
  grepl("^Rscript", exe)
}


### helpers

check_named_not_reserved <- function(alist, reserved) {

  if (!is.list(alist))
    stop("`alist` must be a list", call. = FALSE)

  nms <- names(alist)

  if (is.null(nms) || !all(nzchar(nms))) {
    stop("`alist` must be a fully named list", call. = FALSE)
  }

  bad <- nms %in% reserved

  if (any(bad)) {
    stop(
      "These names are reserved and cannot be used: ",
      paste(nms[bad], collapse = ", "),
      call. = FALSE
    )
  }

  TRUE
}


merge_params <- function(params, one) {
  params <- params[setdiff(names(params), names(one))]
  c(params, one)
}

## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(eval = TRUE)
library(Rsimcity)

## ----example------------------------------------------------------------------
runner <- Rsimcity::Runner$new("example")
runner$params <- list(N = 100)
runner$design <- list(mu = c(0, 1, 2))

runner$step <- function(N, mu) {
  data.frame(x = stats::rnorm(N, mean = mu))
}

# Aggregate function: compute mean of x for the condition
runner$aggregate <- function(data, mu) {
  data.frame(mu = mu, mean_x = mean(data$x))
}

# Run the experiment (Rep = number of replications per condition)
res <- runner$experiment(Rep = 10, progress = FALSE)

head(res)

